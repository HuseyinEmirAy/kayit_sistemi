<?php
require __DIR__.'/config.php';
if (empty($_SESSION['uid'])) { header('Location: login.php'); exit; }

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');
$q    = $_GET['q']    ?? '';

$sql = "SELECT * FROM visits WHERE visit_date BETWEEN ? AND ?";
$params = [$from, $to];
if ($q){
    $sql .= " AND (full_name LIKE ? OR to_whom LIKE ? OR reason LIKE ? OR note LIKE ?)";
    $like = "%$q%";
    array_push($params, $like,$like,$like,$like);
}
$sql .= " ORDER BY visit_date DESC, visit_time DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
$total = count($rows);
?>
<!doctype html><html lang="tr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Yönetici Paneli</title>
<link rel="stylesheet" href="assets/style.css">
</head><body>
<div class="container">
  <div class="header">
    <h1>Ziyaretçi Listesi</h1>
    <div>
      <a class="button ghost" href="people.php">Kişiler</a> <a class="button ghost" href="reasons.php">Nedenler</a> <a class="button ghost" href="logout.php">Çıkış</a>
    </div>
  </div>

  <form method="get" class="filters">
    <label>Başlangıç</label><input type="date" name="from" value="<?=htmlspecialchars($from)?>">
    <label>Bitiş</label><input type="date" name="to" value="<?=htmlspecialchars($to)?>">
    <label>Ara</label><input type="text" name="q" value="<?=htmlspecialchars($q)?>" placeholder="İsim, birim, neden...">
    <button type="submit">Uygula</button>
    <a class="button" href="export_xlsx.php?from=<?=urlencode($from)?>&to=<?=urlencode($to)?>&q=<?=urlencode($q)?>">XLSX İndir</a>
  </form>

  <div class="meta">Toplam kayıt: <?=$total?></div>

  <table>
    <thead><tr>
      <th>Tarih</th><th>Saat</th><th>Adı Soyadı</th><th>Kime Geldi</th><th>Neden</th><th>Not</th>
    </tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?=htmlspecialchars(tr_date($r['visit_date']))?></td>
        <td><?=htmlspecialchars(substr($r['visit_time'],0,5))?></td>
        <td><?=htmlspecialchars($r['full_name'])?></td>
        <td><?=htmlspecialchars($r['to_whom'])?></td>
        <td><?=htmlspecialchars($r['reason'])?></td>
        <td><?=htmlspecialchars($r['note'])?></td>
      </tr>
    <?php endforeach; ?>
    <?php if(!$rows): ?><tr><td colspan="6">Kayıt yok</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
</body></html>
