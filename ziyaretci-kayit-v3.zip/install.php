<?php
require __DIR__.'/config.php';

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS visits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  visit_date DATE NOT NULL,
  visit_time TIME NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  to_whom VARCHAR(120) NOT NULL,
  reason VARCHAR(200) NOT NULL,
  note TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS people (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  department VARCHAR(120) NULL,
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reasons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;

$pdo->exec($sql);

// İlk admin
$username = 'admin';
$passplain = bin2hex(random_bytes(4)); // 8 karakter
$hash = password_hash($passplain, PASSWORD_DEFAULT);
$stmt = $pdo->prepare("INSERT IGNORE INTO users(username, password_hash) VALUES(?,?)");
$stmt->execute([$username, $hash]);

// Örnek kişiler (yoksa ekle)
$pdo->exec("INSERT INTO people(name, department, active) VALUES
 ('Genel Müdürlük', 'Yönetim', 1),
 ('Muhasebe', 'Mali İşler', 1),
 ('İK', 'İnsan Kaynakları', 1),
 ('Editör Masası', 'Editoryal', 1),
 ('Teknik', 'BT', 1)
 ON DUPLICATE KEY UPDATE name=VALUES(name)");

// Örnek nedenler (yoksa ekle)
$pdo->exec("INSERT INTO reasons(name, active) VALUES
 ('Görüşme',1),('Kargo/Teslimat',1),('İş Başvurusu',1),
 ('Servis',1),('Toplantı',1),('Diğer',1)
");

echo "<h2>Kurulum tamamlandı</h2>";
echo "<p><b>Admin:</b> {$username}<br><b>Geçici Şifre:</b> {$passplain}</p>";
echo '<p><a href="login.php">Girişe git</a></p>';
?>
