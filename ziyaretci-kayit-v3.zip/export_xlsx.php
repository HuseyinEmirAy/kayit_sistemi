<?php
require __DIR__.'/config.php';
if (empty($_SESSION['uid'])) { header('Location: login.php'); exit; }

$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to']   ?? date('Y-m-d');
$q    = $_GET['q']    ?? '';

$sql = "SELECT visit_date, visit_time, full_name, to_whom, reason, note FROM visits WHERE visit_date BETWEEN ? AND ?";
$params = [$from, $to];
if ($q){
    $sql .= " AND (full_name LIKE ? OR to_whom LIKE ? OR reason LIKE ? OR note LIKE ?)";
    $like = "%$q%";
    array_push($params, $like,$like,$like,$like);
}
$sql .= " ORDER BY visit_date DESC, visit_time DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Build minimal XLSX (OpenXML) without external libs
function xlsx_cell($col, $row){ // convert 0-index col to A1
    $c = '';
    $col++;
    while($col){
        $m = ($col-1)%26;
        $c = chr(65+$m) . $c;
        $col = intval(($col-$m-1)/26);
    }
    return $c . ($row+1);
}
function build_xlsx($headers, $data){
    $sharedStrings = [];
    $sst = [];
    $getS = function($s) use (&$sharedStrings, &$sst){
        if (!isset($sharedStrings[$s])){
            $sharedStrings[$s] = count($sharedStrings);
            $sst[] = $s;
        }
        return $sharedStrings[$s];
    };

    // worksheet xml
    $rowsxml = '';
    // header row
    $r = 0;
    $rowsxml .= '<row r="'.($r+1).'">';
    foreach($headers as $i=>$h){
        $idx = $getS($h);
        $rowsxml .= '<c r="'.xlsx_cell($i,$r).'" t="s"><v>'.$idx.'</v></c>';
    }
    $rowsxml .= '</row>';
    // data rows
    foreach($data as $row){
        $r++;
        $rowsxml .= '<row r="'.($r+1).'">';
        foreach($row as $i=>$v){
            if ($i==0){ // date as string human readable
                $v = $v;
            }
            $idx = $getS((string)$v);
            $rowsxml .= '<c r="'.xlsx_cell($i,$r).'" t="s"><v>'.$idx.'</v></c>';
        }
        $rowsxml .= '</row>';
    }

    $worksheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'.
    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'.
    '<sheetData>'.$rowsxml.'</sheetData></worksheet>';

    $sstxml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'.
    '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="'.count($sst).'" uniqueCount="'.count($sst).'">';
    foreach($sst as $s){
        $sstxml .= '<si><t>'.htmlspecialchars($s, ENT_XML1|ENT_QUOTES, "UTF-8").'</t></si>';
    }
    $sstxml .= '</sst>';

    $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'.
    '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '.
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'.
    '<sheets><sheet name="Ziyaretler" sheetId="1" r:id="rId1"/></sheets></workbook>';

    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'.
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'.
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'.
    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'.
    '</Relationships>';

    $ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'.
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'.
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'.
    '<Default Extension="xml" ContentType="application/xml"/>'.
    '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'.
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'.
    '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'.
    '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'.
    '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'.
    '</Types>';

    $app = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'.
    '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '.
    'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'.
    '<Application>PHP</Application></Properties>';

    $core = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'.
    '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '.
    'xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Ziyaretler</dc:title></cp:coreProperties>';

    // pack zip
    $zip = new ZipArchive();
    $tmp = tempnam(sys_get_temp_dir(), 'xlsx');
    $zip->open($tmp, ZipArchive::OVERWRITE);
    $zip->addFromString('[Content_Types].xml', $ct);
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $zip->addFromString('docProps/app.xml', $app);
    $zip->addFromString('docProps/core.xml', $core);
    $zip->addFromString('xl/_rels/workbook.xml.rels', $rels);
    $zip->addFromString('xl/workbook.xml', $workbook);
    $zip->addFromString('xl/worksheets/sheet1.xml', $worksheet);
    $zip->addFromString('xl/sharedStrings.xml', $sstxml);
    $zip->close();
    return $tmp;
}

// Prepare data
$headers = ['TARİH','SAAT','ADI SOYADI','KİME GELDİ','ZİYARET NEDENİ','NOT'];
$data = [];
foreach($rows as $r){
    $data[] = [
        $r['visit_date'], substr($r['visit_time'],0,5), $r['full_name'], $r['to_whom'], $r['reason'], $r['note']
    ];
}

$tmp = build_xlsx($headers, $data);
$fname = 'ziyaretler_'.date('Ymd_His').'.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="'.$fname.'"');
header('Content-Length: '.filesize($tmp));
readfile($tmp);
unlink($tmp);
exit;
?>
