<?php
require __DIR__.'/config.php';

$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $visit_date = $_POST['visit_date'] ?? date('Y-m-d');
    $visit_time = $_POST['visit_time'] ?? date('H:i');
    $full_name  = trim($_POST['full_name'] ?? '');
    $to_whom    = trim($_POST['to_whom'] ?? '');
    $reason     = trim($_POST['reason'] ?? '');
    $note       = trim($_POST['note'] ?? '');

    if ($full_name && $to_whom && $reason){
        $stmt = $pdo->prepare("INSERT INTO visits(visit_date, visit_time, full_name, to_whom, reason, note) VALUES (?,?,?,?,?,?)");
        $stmt->execute([$visit_date, $visit_time, $full_name, $to_whom, $reason, $note]);
        $success = 'Kayıt alındı. Teşekkürler.';
    } else {
        $error = 'Lütfen zorunlu alanları doldurunuz.';
    }
}

// Aktif kişiler
$people = [];
try { $people = $pdo->query("SELECT name FROM people WHERE active=1 ORDER BY name ASC")->fetchAll(PDO::FETCH_COLUMN); } catch(Exception $e){ $people=[]; }
// Aktif nedenler
$reasons = [];
try { $reasons = $pdo->query("SELECT name FROM reasons WHERE active=1 ORDER BY name ASC")->fetchAll(PDO::FETCH_COLUMN); } catch(Exception $e){ $reasons=[]; }
?>
<!doctype html><html lang="tr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ziyaretçi Kayıt</title>
<link rel="stylesheet" href="assets/style.css">
</head><body>
<div class="container">
  <h1>Ziyaretçi Kayıt</h1>
  <?php if($success): ?><div class="success"><?=$success?></div><?php endif; ?>
  <?php if($error): ?><div class="alert"><?=$error?></div><?php endif; ?>
  <form method="post" class="grid">
    <div>
      <label>Tarih</label>
      <input type="date" name="visit_date" value="<?=htmlspecialchars(date('Y-m-d'))?>" required>
    </div>
    <div>
      <label>Saat</label>
      <input type="time" name="visit_time" value="<?=htmlspecialchars(date('H:i'))?>" required>
    </div>
    <div class="col-2">
      <label>Adı Soyadı</label>
      <input type="text" name="full_name" placeholder="Ad Soyad" required>
    </div>
    <div>
      <label>Kime Geldi</label>
      <select name="to_whom" required>
        <option value="">Seçiniz</option>
        <?php foreach($people as $p): ?>
        <option value="<?=$p?>"><?=$p?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <label>Ziyaret Nedeni</label>
      <select name="reason" required>
        <option value="">Seçiniz</option>
        <?php foreach($reasons as $opt): ?>
        <option value="<?=$opt?>"><?=$opt?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-2">
      <label>Not (opsiyonel)</label>
      <input type="text" name="note" placeholder="Kısa not">
    </div>
    <div class="col-2">
      <button type="submit">Kaydet</button>
      <a class="button ghost" href="login.php">Yönetici</a>
    </div>
  </form>
</div>
</body></html>
