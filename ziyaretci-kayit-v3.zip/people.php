<?php
require __DIR__.'/config.php';
if (empty($_SESSION['uid'])) { header('Location: login.php'); exit; }

// İşlemler (ekle/sil/aktiflik)
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $action = $_POST['action'] ?? '';
    if ($action==='add'){
        $name = trim($_POST['name'] ?? '');
        $dept = trim($_POST['department'] ?? '');
        if ($name){
            $stmt = $pdo->prepare("INSERT INTO people(name, department, active) VALUES(?,?,1)");
            $stmt->execute([$name, $dept]);
            header("Location: people.php?ok=1"); exit;
        }
    } elseif ($action==='toggle'){
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("UPDATE people SET active = 1-active WHERE id=?")->execute([$id]);
        header("Location: people.php"); exit;
    } elseif ($action==='delete'){
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM people WHERE id=?")->execute([$id]);
        header("Location: people.php"); exit;
    }
}

$q = $_GET['q'] ?? '';
$sql = "SELECT * FROM people";
$params = [];
if ($q){
    $sql .= " WHERE name LIKE ? OR department LIKE ?";
    $like = "%$q%";
    $params = [$like,$like];
}
$sql .= " ORDER BY active DESC, name ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
?>
<!doctype html><html lang="tr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kişiler</title>
<link rel="stylesheet" href="assets/style.css">
</head><body>
<div class="container">
  <div class="header">
    <h1>Kime Gelindi (Kişiler)</h1>
    <div>
      <a class="button ghost" href="admin.php">Kayıtlar</a>
      <a class="button ghost" href="logout.php">Çıkış</a>
    </div>
  </div>

  <form method="post" class="grid">
    <div class="col-2"><h3>Yeni Kişi/Birim Ekle</h3></div>
    <div>
      <label>Ad / Birim Adı</label>
      <input type="text" name="name" required>
    </div>
    <div>
      <label>Departman (ops)</label>
      <input type="text" name="department">
    </div>
    <div class="col-2">
      <input type="hidden" name="action" value="add">
      <button type="submit">Ekle</button>
    </div>
  </form>

  <form method="get" class="filters">
    <label>Ara</label><input type="text" name="q" value="<?=htmlspecialchars($q)?>" placeholder="İsim / departman">
    <button type="submit">Ara</button>
  </form>

  <table>
    <thead><tr><th>Ad</th><th>Departman</th><th>Durum</th><th>İşlem</th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr>
        <td><?=htmlspecialchars($r['name'])?></td>
        <td><?=htmlspecialchars($r['department'])?></td>
        <td><?= $r['active'] ? 'Aktif' : 'Pasif' ?></td>
        <td>
          <form method="post" style="display:inline">
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="id" value="<?=$r['id']?>">
            <button type="submit" class="button"><?= $r['active'] ? 'Pasifleştir' : 'Aktifleştir' ?></button>
          </form>
          <form method="post" style="display:inline" onsubmit="return confirm('Silinsin mi?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?=$r['id']?>">
            <button type="submit" class="button ghost">Sil</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if(!$rows): ?><tr><td colspan="4">Kayıt yok</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
</body></html>
