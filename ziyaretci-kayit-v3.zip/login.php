<?php
require __DIR__.'/config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $u = trim($_POST['username'] ?? '');
    $p = trim($_POST['password'] ?? '');
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username=?");
    $stmt->execute([$u]);
    $row = $stmt->fetch();
    if ($row && password_verify($p, $row['password_hash'])){
        $_SESSION['uid'] = $row['id'];
        $_SESSION['uname'] = $row['username'];
        header('Location: admin.php'); exit;
    } else {
        $error = 'Kullanıcı adı veya şifre hatalı.';
    }
}
?>
<!doctype html><html lang="tr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Giriş</title>
<link rel="stylesheet" href="assets/style.css">
</head><body>
<div class="container small">
  <h2>Yönetici Girişi</h2>
  <?php if($error): ?><div class="alert"><?=$error?></div><?php endif; ?>
  <form method="post">
    <label>Kullanıcı Adı</label>
    <input type="text" name="username" required>
    <label>Şifre</label>
    <input type="password" name="password" required>
    <button type="submit">Giriş</button>
  </form>
</div>
</body></html>
