<?php
// cPanel MySQL bilgilerinizi girin
$DB_HOST = 'localhost';
$DB_NAME = 'turkinform_visit';
$DB_USER = 'visit_user';
$DB_PASS = 'SifreBuraya';

try {
    $pdo = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die('Veritabanı bağlantı hatası: ' . htmlspecialchars($e->getMessage()));
}

if (session_status() === PHP_SESSION_NONE) { session_start(); }

function tr_date($dateYmd){
    setlocale(LC_TIME, 'tr_TR.UTF-8', 'tr_TR', 'tr');
    $ts = strtotime($dateYmd);
    $gunler = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'];
    return strftime('%d %B %Y ', $ts) . $gunler[date('w',$ts)];
}
?>
